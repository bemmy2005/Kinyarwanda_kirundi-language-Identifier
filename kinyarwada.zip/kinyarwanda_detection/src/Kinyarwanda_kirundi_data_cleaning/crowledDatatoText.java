package Kinyarwanda_kirundi_data_cleaning;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;

public class crowledDatatoText {

	private crowledDatatoText() {}
	public static StringBuilder reporter = new StringBuilder();
	   public static void main (String[] args) throws Exception{
		   writeReportToFile("Kinyarwanda_corpus");
	     //StringBuilder sb = new StringBuilder();
	     BufferedReader br = new BufferedReader(new FileReader("kinyarwanda_igihe.txt"));
	     String line;
	     while ( (line=br.readLine()) != null) {
	    	 reporter.append(line);
	       // or
	       //  sb.append(line).append(System.getProperty("line.separator"));
	     }
	     String nohtml = reporter.toString().replaceAll("\\<file.*?>","");
	     String paragraphString= nohtml;
	     //String mytext=paragraphString.replaceAll("\\</?p>", "");
	     String mytext=paragraphString.replaceAll("\\<p>", "");
	     String lastclaenString=mytext;
	     String clear=lastclaenString.replaceAll("</p>", ".");
	     
	     writeReportToFile("english_report.txt");
	     
	     System.out.println(clear);
	     report(clear);
	}
	   public static void writeReportToFile(String fileName) throws Exception{
	        Files.write(Paths.get(fileName), reporter.toString().getBytes());
	        reporter = new StringBuilder();
		}
	   public static void report(String msg){
			reporter.append(msg+"\n");
		}
}
