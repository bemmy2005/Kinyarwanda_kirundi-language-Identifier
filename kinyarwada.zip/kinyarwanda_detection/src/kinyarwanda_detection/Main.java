package kinyarwanda_detection;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//languageDetecter();
		languageInput();
		userTextInput();
		
	}
	private static void userTextInput() throws Exception{
		
		Scanner input=new Scanner(System.in);
		System.out.println("Kinyarwanda" +"," +"or" +"," + "Kirundi");
		System.out.println("Enter a text in one of the above language: ");
		System.out.println("==============================================");
		String myText=input.nextLine();
		String []userInputtext=myText.split("\\s+");
	}
	private static void languageInput()throws Exception{
		///===================KINYARWANDA=================================
		String KinyarwandaCorpus=new String (Files.readAllBytes(Paths.get("kinyarwanda")));
		String[] Kinyarwanda_words = KinyarwandaCorpus.split("\\s+"); // match one or more spaces   
		///===================KIRUNDI=================================
		String kirundi=new String (Files.readAllBytes(Paths.get("kirundi")));
		String[] Kirundi_words = kirundi.split("\\s+"); // match one or more spaces  
		///===================OUTPUT================================
		System.out.println("Kinyarwanda corpus used has:: "+KinyarwandaCorpus.length()+" Characters and "+Kinyarwanda_words.length+" words");
		System.out.println("English corpus used has:: "+kirundi.length()+" Characters and "+Kirundi_words.length+" words");
		System.out.println("==============================================");
		
	}
//	public static void languageDetecter() throws Exception{
//		userTextInput();
//		languageInput();
//		String []userInputtext=new String[10];
//		String [] Kinyarwanda_words=new String[10];
//		String [] Kirundi_words=new String[10];
//		for(int i = 1; i <userInputtext.length; i++)
//        {
//            for(int j = 0; j <  Kinyarwanda_words.length; j++)
//            {
//                if(userInputtext [i].equals(Kinyarwanda_words[j]))
//                {
//                    System.out.println("The detected language is Kinyarwanda");
//                }
//                else {
//                	for (int l=1;l<userInputtext.length;l++){
//                		for(int k=0;k<Kirundi_words.length;k++){
//                			if(userInputtext[l].equals (Kirundi_words[k])){
//                				System.out.println("The detected language is English");
//                			}
//                		}
//                	}
//					
//				}
//            }
//        }
	//}

}
